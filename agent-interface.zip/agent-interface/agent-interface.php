<?php
/**
 * Plugin Name: Agent Interface (Multi-Resource + Settings)
 * Description: Public manifest + read-only resources (Posts, Pages, WooCommerce Products) for AI agents, with settings and optional token for non-manifest endpoints.
 * Version: 0.4.0
 * Author: Varun Sawant
 * Author URI: https://example.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

/* -------------------------------------------------------
 * Options & Defaults
 * ----------------------------------------------------- */
const AI_AGENT_OPTION_KEY = 'ai_agent_options';

function ai_agent_default_options(): array {
  return [
    'enable_posts'    => 1,  // expose posts
    'enable_pages'    => 1,  // expose pages
    'enable_products' => 0,  // expose Woo products (if Woo is present)
    'require_token'   => 0,  // public by default (non-manifest)
    'token'           => '', // auto-filled on activation
  ];
}

function ai_agent_get_options(): array {
  $opts = get_option(AI_AGENT_OPTION_KEY, []);
  return array_merge(ai_agent_default_options(), is_array($opts) ? $opts : []);
}

function ai_agent_update_options(array $new) {
  $opts   = ai_agent_get_options();
  $merged = array_merge($opts, $new);
  update_option(AI_AGENT_OPTION_KEY, $merged, true);
}

/* -------------------------------------------------------
 * Activation / Deactivation
 * ----------------------------------------------------- */
register_activation_hook(__FILE__, function () {
  $opts = ai_agent_get_options();
  if (empty($opts['token'])) {
    $rand = wp_generate_password(32, false, false);
    $opts['token'] = 'sk_live_' . strtolower($rand);
  }
  update_option(AI_AGENT_OPTION_KEY, $opts, true);

  ai_agent_register_manifest_rewrite();
  flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
});

/* -------------------------------------------------------
 * Helpers: Serialization
 * ----------------------------------------------------- */
if (!function_exists('ai_serialize_post')) {
  function ai_serialize_post(WP_Post $p) {
    $tags   = wp_get_post_tags($p->ID, ['fields' => 'names']);
    $cats   = wp_get_post_categories($p->ID, ['fields' => 'names']);
    $author = get_userdata($p->post_author);

    return [
      "id"           => (string)$p->ID,
      "title"        => html_entity_decode(get_the_title($p), ENT_QUOTES),
      "slug"         => $p->post_name,
      "excerpt"      => wp_strip_all_tags(get_the_excerpt($p->ID)),
      "content_html" => apply_filters('the_content', $p->post_content),
      "author"       => $author ? $author->display_name : null,
      "tags"         => array_values($tags ?: []),
      "categories"   => array_values($cats ?: []),
      "created_at"   => get_post_time('c', true, $p),
      "updated_at"   => get_post_modified_time('c', true, $p),
      "url"          => get_permalink($p),
      "lang"         => get_bloginfo('language') ?: null,
    ];
  }
}

if (!function_exists('ai_serialize_page')) {
  function ai_serialize_page(WP_Post $p) {
    return [
      "id"           => (string)$p->ID,
      "title"        => html_entity_decode(get_the_title($p), ENT_QUOTES),
      "slug"         => $p->post_name,
      "content_html" => apply_filters('the_content', $p->post_content),
      "created_at"   => get_post_time('c', true, $p),
      "updated_at"   => get_post_modified_time('c', true, $p),
      "url"          => get_permalink($p),
    ];
  }
}

if (!function_exists('ai_serialize_product')) {
  function ai_serialize_product($prod) {
    if (!$prod) return null;
    $img_id = method_exists($prod, 'get_image_id') ? $prod->get_image_id() : 0;
    return [
      'id'        => (string)$prod->get_id(),
      'title'     => $prod->get_name(),
      'sku'       => $prod->get_sku(),
      'price'     => (float)$prod->get_price(),
      'currency'  => function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : null,
      'in_stock'  => $prod->is_in_stock(),
      'url'       => get_permalink($prod->get_id()),
      'image'     => $img_id ? wp_get_attachment_image_url($img_id, 'full') : null,
      'created_at'=> function_exists('wc_rest_prepare_date_response') ? wc_rest_prepare_date_response($prod->get_date_created(), false) : null,
      'updated_at'=> function_exists('wc_rest_prepare_date_response') ? wc_rest_prepare_date_response($prod->get_date_modified(), false) : null,
    ];
  }
}

/* -------------------------------------------------------
 * Security: permission for NON-manifest endpoints
 * ----------------------------------------------------- */
function ai_agent_check_permission() {
  $opts = ai_agent_get_options();
  if (empty($opts['require_token'])) return true;

  $expected = trim((string)$opts['token']);
  if ($expected === '') return new WP_Error('unauthorized', 'Token not configured', ['status' => 401]);

  $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!$hdr && function_exists('apache_request_headers')) {
    $all = apache_request_headers(); $hdr = $all['Authorization'] ?? '';
  }
  if (stripos($hdr, 'Bearer ') !== 0) {
    return new WP_Error('unauthorized', 'Missing bearer token', ['status' => 401]);
  }
  $got = trim(substr($hdr, 7));
  if (!hash_equals($expected, $got)) {
    return new WP_Error('forbidden', 'Invalid token', ['status' => 403]);
  }
  return true;
}

/* -------------------------------------------------------
 * REST API Routes
 * ----------------------------------------------------- */
add_action('rest_api_init', function () {
  $ns   = 'agent/v1';
  $opts = ai_agent_get_options();

  // 0) Sanity
  register_rest_route($ns, '/ping', [
    'methods'  => 'GET',
    'callback' => fn() => ['ok' => true],
    'permission_callback' => '__return_true',
  ]);

  // 1) Manifest (ALWAYS PUBLIC)
  register_rest_route($ns, '/manifest', [
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function () use ($ns, $opts) {

      // Schemas
      $postSchema = [
        "type" => "object",
        "required" => ["id","title","slug","url","created_at"],
        "properties" => [
          "id"           => ["type"=>"string"],
          "title"        => ["type"=>"string"],
          "slug"         => ["type"=>"string"],
          "excerpt"      => ["type"=>"string"],
          "content_html" => ["type"=>"string"],
          "author"       => ["type"=>"string"],
          "tags"         => ["type"=>"array","items"=>["type"=>"string"]],
          "categories"   => ["type"=>"array","items"=>["type"=>"string"]],
          "created_at"   => ["type"=>"string","format"=>"date-time"],
          "updated_at"   => ["type"=>"string","format"=>"date-time"],
          "url"          => ["type"=>"string","format"=>"uri"],
          "lang"         => ["type"=>"string"]
        ]
      ];
      $pageSchema = [
        "type" => "object",
        "required" => ["id","title","slug","url","created_at"],
        "properties" => [
          "id"           => ["type"=>"string"],
          "title"        => ["type"=>"string"],
          "slug"         => ["type"=>"string"],
          "content_html" => ["type"=>"string"],
          "created_at"   => ["type"=>"string","format"=>"date-time"],
          "updated_at"   => ["type"=>"string","format"=>"date-time"],
          "url"          => ["type"=>"string","format"=>"uri"],
        ]
      ];
      $productSchema = [
        "type" => "object",
        "required" => ["id","title","price","url"],
        "properties" => [
          "id"       => ["type"=>"string"],
          "title"    => ["type"=>"string"],
          "sku"      => ["type"=>"string"],
          "price"    => ["type"=>"number"],
          "currency" => ["type"=>"string"],
          "in_stock" => ["type"=>"boolean"],
          "url"      => ["type"=>"string","format"=>"uri"],
          "image"    => ["type"=>"string","format"=>"uri"],
          "created_at"=>["type"=>"string","format"=>"date-time"],
          "updated_at"=>["type"=>"string","format"=>"date-time"],
        ]
      ];

      // Resource list (based on toggles + Woo presence)
      $resources = [];
      if (!empty($opts['enable_posts'])) {
        $resources[] = ["name"=>"post","list"=>true,"get"=>true,"schema"=>$postSchema];
      }
      if (!empty($opts['enable_pages'])) {
        $resources[] = ["name"=>"page","list"=>true,"get"=>true,"schema"=>$pageSchema];
      }
      if (!empty($opts['enable_products']) && class_exists('WooCommerce')) {
        $resources[] = ["name"=>"product","list"=>true,"get"=>true,"schema"=>$productSchema];
      }

      $payload = [
        "name" => get_bloginfo('name') . " — Agent Interface",
        "version" => "0.4.0",
        "auth" => [
          "manifest"  => "none",
          "resources" => empty($opts['require_token']) ? "none" : "token",
        ],
        "endpoints" => [
          "manifest"  => rest_url($ns . '/manifest'),
          "resources" => rest_url($ns . '/resources'),
        ],
        "resources" => $resources,
        "actions" => [],
        "rate_limits" => [ "read_per_min" => 600 ],
      ];
      return new WP_REST_Response($payload, 200);
    }
  ]);

  /* ---------- POSTS ---------- */
  if (!empty($opts['enable_posts'])) {
    // list
    register_rest_route($ns, '/resources/posts', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args'     => [
        'query'  => ['type' => 'string',  'required' => false],
        'limit'  => ['type' => 'integer', 'required' => false, 'default' => 10],
        'status' => ['type' => 'string',  'required' => false, 'default' => 'publish'],
      ],
      'callback' => function (WP_REST_Request $req) {
        $limit  = max(1, min(100, intval($req->get_param('limit') ?: 10)));
        $query  = trim((string) ($req->get_param('query') ?: ''));
        $status = sanitize_text_field($req->get_param('status') ?: 'publish');

        $args = [
          'post_type'      => 'post',
          'post_status'    => $status,
          'posts_per_page' => $limit,
          'orderby'        => 'date',
          'order'          => 'DESC',
        ];
        if ($query !== '') $args['s'] = $query;

        $q = new WP_Query($args);
        $items = [];
        foreach ($q->posts as $p) { $items[] = ai_serialize_post($p); }

        return new WP_REST_Response(["items" => $items], 200, [
          'X-RateLimit-Limit'     => '600',
          'X-RateLimit-Remaining' => '600',
        ]);
      }
    ]);
    // detail
    register_rest_route($ns, '/resources/posts/(?P<id>\d+)', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args'     => ['id' => ['type'=>'integer','required'=>true]],
      'callback' => function (WP_REST_Request $req) {
        $id = intval($req['id']);
        $p  = get_post($id);
        if (!$p || $p->post_type !== 'post' || $p->post_status !== 'publish') {
          return new WP_Error('not_found', 'Post not found', ['status' => 404]);
        }
        return new WP_REST_Response(ai_serialize_post($p), 200);
      }
    ]);
  }

  /* ---------- PAGES ---------- */
  if (!empty($opts['enable_pages'])) {
    // list
    register_rest_route($ns, '/resources/pages', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args'     => [
        'query'  => ['type' => 'string',  'required' => false],
        'limit'  => ['type' => 'integer', 'required' => false, 'default' => 10],
        'status' => ['type' => 'string',  'required' => false, 'default' => 'publish'],
      ],
      'callback' => function (WP_REST_Request $req) {
        $limit  = max(1, min(100, intval($req->get_param('limit') ?: 10)));
        $query  = trim((string) ($req->get_param('query') ?: ''));
        $status = sanitize_text_field($req->get_param('status') ?: 'publish');

        $args = [
          'post_type'      => 'page',
          'post_status'    => $status,
          'posts_per_page' => $limit,
          'orderby'        => 'date',
          'order'          => 'DESC',
        ];
        if ($query !== '') $args['s'] = $query;

        $q = new WP_Query($args);
        $items = [];
        foreach ($q->posts as $p) { $items[] = ai_serialize_page($p); }

        return new WP_REST_Response(["items" => $items], 200);
      }
    ]);
    // detail
    register_rest_route($ns, '/resources/pages/(?P<id>\d+)', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args'     => ['id' => ['type'=>'integer','required'=>true]],
      'callback' => function (WP_REST_Request $req) {
        $id = intval($req['id']);
        $p  = get_post($id);
        if (!$p || $p->post_type !== 'page' || $p->post_status !== 'publish') {
          return new WP_Error('not_found', 'Page not found', ['status' => 404]);
        }
        return new WP_REST_Response(ai_serialize_page($p), 200);
      }
    ]);
  }

  /* ---------- PRODUCTS (WooCommerce) ---------- */
  if (!empty($opts['enable_products']) && class_exists('WooCommerce')) {
    // list
    register_rest_route($ns, '/resources/products', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args' => [
        'limit' => ['type'=>'integer','default'=>10],
        'query' => ['type'=>'string'],
        'status'=> ['type'=>'string','default'=>'publish'],
      ],
      'callback' => function (WP_REST_Request $req) {
        $limit = max(1, min(100, intval($req->get_param('limit') ?: 10)));
        $query = trim((string)($req->get_param('query') ?: ''));
        $args = [
          'limit'   => $limit,
          'status'  => 'publish',
          'orderby' => 'date',
          'order'   => 'DESC',
          'return'  => 'objects',
        ];
        if ($query !== '') $args['search'] = $query;

        $prods = wc_get_products($args);
        $items = array_values(array_filter(array_map('ai_serialize_product', $prods)));

        return new WP_REST_Response(['items'=>$items], 200);
      }
    ]);
    // detail
    register_rest_route($ns, '/resources/products/(?P<id>\d+)', [
      'methods'  => 'GET',
      'permission_callback' => 'ai_agent_check_permission',
      'args'     => ['id' => ['type'=>'integer','required'=>true]],
      'callback' => function (WP_REST_Request $req) {
        $id = intval($req['id']);
        $prod = wc_get_product($id);
        if (!$prod || $prod->get_status() !== 'publish') {
          return new WP_Error('not_found', 'Product not found', ['status' => 404]);
        }
        return new WP_REST_Response(ai_serialize_product($prod), 200);
      }
    ]);
  }
});

/* -------------------------------------------------------
 * Pretty URL for manifest (ALWAYS PUBLIC)
 *  /.well-known/agent/manifest.json
 * ----------------------------------------------------- */
function ai_agent_register_manifest_rewrite() {
  add_rewrite_rule('^\.well-known/agent/manifest\.json$', 'index.php?ai_agent_manifest=1', 'top');
}
add_action('init', 'ai_agent_register_manifest_rewrite');

add_filter('query_vars', function ($vars) {
  $vars[] = 'ai_agent_manifest';
  return $vars;
});

add_action('template_redirect', function () {
  if (get_query_var('ai_agent_manifest')) {
    $resp = rest_do_request(new WP_REST_Request('GET', '/agent/v1/manifest'));
    $data = is_wp_error($resp) ? ['error' => $resp->get_error_message()] : $resp->get_data();
    status_header(200);
    header('Content-Type: application/json; charset=utf-8');
    echo wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
  }
});

/* -------------------------------------------------------
 * Admin Settings Page
 * ----------------------------------------------------- */
add_action('admin_menu', function () {
  add_menu_page(
    'Agent Interface',
    'Agent Interface',
    'manage_options',
    'ai-agent-settings',
    'ai_agent_render_settings_page',
    'dashicons-robot',
    65
  );
});

function ai_agent_render_settings_page() {
  if (!current_user_can('manage_options')) return;

  // Handle save
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ai_agent_save'])) {
    check_admin_referer('ai_agent_save_settings');

    $enable_posts    = isset($_POST['enable_posts']) ? 1 : 0;
    $enable_pages    = isset($_POST['enable_pages']) ? 1 : 0;
    $enable_products = isset($_POST['enable_products']) ? 1 : 0;
    $require_token   = isset($_POST['require_token']) ? 1 : 0;
    $token           = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';

    $opts = ai_agent_get_options();
    if ($require_token && $token === '') $token = $opts['token'];

    ai_agent_update_options([
      'enable_posts'    => $enable_posts,
      'enable_pages'    => $enable_pages,
      'enable_products' => $enable_products,
      'require_token'   => $require_token,
      'token'           => $token,
    ]);

    echo '<div class="updated"><p>Settings saved.</p></div>';
  }

  $opts = ai_agent_get_options();
  $has_woo = class_exists('WooCommerce');
  $manifest_rest   = rest_url('agent/v1/manifest');
  $manifest_pretty = home_url('/.well-known/agent/manifest.json');
  ?>
  <div class="wrap">
    <h1>Agent Interface — Settings</h1>
    <p>Manifest is <strong>public</strong>. Other endpoints can be public or token-protected.</p>

    <h2>Status</h2>
    <table class="widefat striped" style="max-width: 920px;">
      <tbody>
        <tr>
          <th scope="row" style="width:220px;">Manifest (REST)</th>
          <td><code><?php echo esc_html($manifest_rest); ?></code></td>
        </tr>
        <tr>
          <th scope="row">Manifest (Well-known)</th>
          <td><code><?php echo esc_html($manifest_pretty); ?></code></td>
        </tr>
        <tr>
          <th scope="row">Posts endpoint</th>
          <td><code><?php echo esc_html(rest_url('agent/v1/resources/posts')); ?></code></td>
        </tr>
        <tr>
          <th scope="row">Pages endpoint</th>
          <td><code><?php echo esc_html(rest_url('agent/v1/resources/pages')); ?></code></td>
        </tr>
        <?php if ($has_woo): ?>
        <tr>
          <th scope="row">Products endpoint</th>
          <td><code><?php echo esc_html(rest_url('agent/v1/resources/products')); ?></code></td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <form method="post" style="margin-top:20px; max-width:920px;">
      <?php wp_nonce_field('ai_agent_save_settings'); ?>
      <input type="hidden" name="ai_agent_save" value="1" />

      <h2>Features</h2>
      <p><label><input type="checkbox" name="enable_posts" <?php checked(!empty($opts['enable_posts'])); ?> /> Expose <strong>Posts</strong></label></p>
      <p><label><input type="checkbox" name="enable_pages" <?php checked(!empty($opts['enable_pages'])); ?> /> Expose <strong>Pages</strong></label></p>
      <?php if ($has_woo): ?>
        <p><label><input type="checkbox" name="enable_products" <?php checked(!empty($opts['enable_products'])); ?> /> Expose <strong>WooCommerce Products</strong></label></p>
      <?php else: ?>
        <p><em>WooCommerce not detected. Install WooCommerce to enable Products endpoint.</em></p>
      <?php endif; ?>

      <h2 style="margin-top:20px;">Security for non-manifest endpoints</h2>
      <p>
        <label>
          <input type="checkbox" name="require_token" <?php checked(!empty($opts['require_token'])); ?> />
          Require <strong>Bearer token</strong> for access to resources (manifest remains public)
        </label>
      </p>
      <p>
        <label>Token
          <input type="text" name="token" value="<?php echo esc_attr($opts['token']); ?>" style="width: 420px;" />
        </label>
        <button type="button" class="button" onclick="
          const f=this.closest('form');
          const inp=f.querySelector('input[name=token]');
          const rand='sk_live_'+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);
          inp.value=rand;
        ">Generate New</button>
      </p>

      <p style="margin-top:20px;">
        <button class="button button-primary">Save Settings</button>
      </p>
    </form>

    <h2>Quick Tests</h2>
    <p><strong>Manifest (always public)</strong></p>
    <pre><?php echo esc_html($manifest_rest); ?></pre>
    <pre><?php echo esc_html($manifest_pretty); ?></pre>

    <p><strong>Resources (public mode)</strong></p>
    <pre><?php echo esc_html(rest_url('agent/v1/resources/posts?limit=5')); ?></pre>
    <pre><?php echo esc_html(rest_url('agent/v1/resources/pages?limit=5')); ?></pre>
    <?php if ($has_woo): ?>
      <pre><?php echo esc_html(rest_url('agent/v1/resources/products?limit=5')); ?></pre>
    <?php endif; ?>

    <p><strong>Resources (token mode)</strong></p>
    <pre>curl -H "Authorization: Bearer <?php echo esc_html($opts['token']); ?>" <?php echo esc_html(rest_url('agent/v1/resources/posts?limit=5')); ?></pre>

    <p style="margin-top:40px; font-size:12px; color:#666;">
      Agent Interface Plugin v0.4.0 — Developed by Varun Sawant. Licensed under GPLv2.
    </p>
  </div>
  <?php
}
